<?php

return array( 
    'plBasePropertyException'           =>  'exceptions/base/property.php',
);

?>
