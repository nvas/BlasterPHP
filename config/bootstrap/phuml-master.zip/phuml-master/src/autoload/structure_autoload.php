<?php

return array( 
    'plStructureGenerator'                          =>  'interfaces/generator.php',
    'plStructureTokenparserGenerator'               =>  'classes/generator/tokenparser.php',

    'plStructureGeneratorNotFoundException'         =>  'exceptions/generator/notFound.php',
);

?>
