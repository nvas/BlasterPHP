<?php

return array( 
    'plPhuml'                                    =>  'classes/phuml.php',
    'plPhumlInvalidProcessorException'           =>  'exceptions/phuml/invalidProcessor.php',
    'plPhumlInvalidProcessorChainException'      =>  'exceptions/phuml/invalidProcessorChain.php',
);

?>
